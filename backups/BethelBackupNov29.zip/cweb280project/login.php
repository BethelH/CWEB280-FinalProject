<?php
function my_autoloader( $className )
{
    require_once( "classes/$className.class.php" );
}

spl_autoload_register( "my_autoloader" );
session_start();

$db = new DbObject();
//ensure the user is using a secure connection
if(!isset($_SERVER["HTTPS"]) || !$_SERVER["HTTPS"])
{
   //redirect the user to a secure version of teh requested page - SSL (Secure Socket Layer)
    header("HTTP/1.1 301 Moved Permanently");
    
    //now tell the browser where the new location is
    //the new location is simple https:// instead of http://
    header("Location: https://" . $_SERVER["HTTP_HOST"] . $_SERVER["REQUEST_URI"]);
    exit(); //tell php to stop all other execution of any following code 
}

//if they are already logged in, redirect to index page
if(isset($_SESSION["loggedIn"]))
{
    header("Location: index.php");
}
//check for a valid username and password if submitted
if(isset($_POST["submitLogin"]))
{
    $passwordCheck = new PasswordChecker();
    
    // check the posted username and password 
    if(!empty($_POST["username"]))
    {
       
        $_POST["submitLogin"] = $passwordCheck->isValid($_POST["username"],
                $_POST["password"]);

        //  regenerate the session id
        session_regenerate_id(true);   
        //if the login is valid redirect to index page
        if($_POST["submitLogin"])
        {
            $_SESSION["username"] = $_POST["username"];
            header("Location: index.php");
        }
        //display error message if wrong username or password
        else
        {  
         echo "<div>Invalid username or password</div>";               
        }
    }
}
$form = new HtmlForm();
?>

<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
      
         <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css">
                  <link type=text/css" rel="stylesheet" href="SecretStyles.css" />
        <title>Login</title>
    </head>
    <body>
        <div class="container">
<!--        <h2>Wanna join? <a href="register.php">click here</a> to become a member</h2>
        <h2>You could also <a href="CreateSecret.php">click here</a> to create a secret page</h2>
        <h2>Forgot Your Password? <a href="ResetPassword.php">click here</a> to reset your password</h2>-->
            <?php
    

            $form->renderStart("loginForm", "Enter your username and password");
            $form->renderTextbox("username", "Username", true);
            $form->renderPassword("password", "Password", true);
            $form->renderSubmitEnd("submitLogin", "Submit");
         
            ?>
<div id="linking">
                <p> Don't have an account?<a href="register.php" > Click Here</a> to register!</a></p>
             
            </div>
        </div>
            <div id="toHome">
            <a href="index.php" >    <img id="logo1" alt ="classified logo" src="style\class.png"style="width:100px;height:80px"/></a>
        </div>
    </body>
</html>
