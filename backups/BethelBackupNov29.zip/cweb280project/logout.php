<?php
/*
 * Purpose: Used to facilitate logging a user out. 
 */
session_start();


?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Logout</title>
    </head>
    <body>
        <div >
            <?php
                //if the user is logged in - log them out by setting their
                //loggedin session variable to false.
                if(isset($_SESSION["loggedIn"]) && $_SESSION["loggedIn"])
                {
                    $_SESSION["loggedIn"] = false;
                    echo "<p>You have been logged out";
                }
                //otherwise redirect them back to the login page - because they 
                //tried to logout without being logged in - this is done by accessing
                //the logout.php page directly. 
                else
                {
                    echo "<script language='JavaScript'> window.location='login.php'</script>";
                }
            ?>
            <li><a href="login.php">Log in to the website</a></li>
            <li><a href="register.php">Register</a></li>
        </div>
    </body>
</html>
