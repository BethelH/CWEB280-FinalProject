<?php
if(isset($_POST["username"]))
{
    $db = new DbObject();
    $username = $_POST['username'];
    $results = $db->select("username", "Member", "username=" . $username);
    $find = mysql_num_rows($results);
    echo $find;
}


